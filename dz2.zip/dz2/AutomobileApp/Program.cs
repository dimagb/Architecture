﻿using System.Text;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

string dbPath = "automobiles.db";
string brandCsv = Path.Combine(AppContext.BaseDirectory, "carbrands.csv");
string carCsv = Path.Combine(AppContext.BaseDirectory, "cars.csv");

var db = new DatabaseManager(dbPath);
db.InitializeDatabase(brandCsv, carCsv);

Console.WriteLine();

string choice;
do
{
    Console.WriteLine("╔══════════════════════════════════════════════╗");
    Console.WriteLine("║         УПРАВЛЕНИЕ АВТОМОБИЛЯМИ               ║");
    Console.WriteLine("╠══════════════════════════════════════════════╣");
    Console.WriteLine("║ 1 — Показать все марки                       ║");
    Console.WriteLine("║ 2 — Показать все автомобили                  ║");
    Console.WriteLine("║ 3 — Добавить автомобиль                      ║");
    Console.WriteLine("║ 4 — Редактировать автомобиль                 ║");
    Console.WriteLine("║ 5 — Удалить автомобиль                       ║");
    Console.WriteLine("║ 6 — Отчёты                                   ║");
    Console.WriteLine("║ 7 — Фильтр по марке [ГРУППА Г]               ║");
    Console.WriteLine("║ 8 — Экспорт в CSV [ГРУППА Б]                 ║");
    Console.WriteLine("║ 0 — Выход                                    ║");
    Console.WriteLine("╚══════════════════════════════════════════════╝");
    Console.Write("Ваш выбор: ");

    choice = Console.ReadLine()?.Trim() ?? "";
    Console.WriteLine();

    switch (choice)
    {
        case "1": ShowBrands(db); break;
        case "2": ShowCars(db); break;
        case "3": AddCar(db); break;
        case "4": EditCar(db); break;
        case "5": DeleteCar(db); break;
        case "6": ReportsMenu(db); break;
        case "7": FilterByBrand(db); break;
        case "8": ExportCsv(db); break;
        case "0": Console.WriteLine("До свидания!"); break;
        default: Console.WriteLine("Неверный пункт меню."); break;
    }
    Console.WriteLine();
} while (choice != "0");

// ==================== Функции пунктов меню ====================

static void ShowBrands(DatabaseManager db)
{
    Console.WriteLine("--- Все марки ---");
    var brands = db.GetAllBrands();
    foreach (var brand in brands) Console.WriteLine(" " + brand);
    Console.WriteLine($"Итого: {brands.Count}");
}

static void ShowCars(DatabaseManager db)
{
    Console.WriteLine("--- Все автомобили ---");
    var cars = db.GetAllCars();
    foreach (var car in cars) Console.WriteLine(" " + car);
    Console.WriteLine($"Итого: {cars.Count}");
}

static void AddCar(DatabaseManager db)
{
    Console.WriteLine("--- Добавление автомобиля ---");
    Console.WriteLine("Доступные марки:");
    var brands = db.GetAllBrands();
    foreach (var brand in brands) Console.WriteLine(" " + brand);

    Console.Write("ID марки: ");
    if (!int.TryParse(Console.ReadLine(), out int brandId))
    {
        Console.WriteLine("Ошибка: введите целое число.");
        return;
    }

    Console.Write("Название модели: ");
    string name = Console.ReadLine()?.Trim() ?? "";
    if (name.Length == 0)
    {
        Console.WriteLine("Ошибка: название не может быть пустым.");
        return;
    }

    Console.Write("Мощность (л.с.): ");
    if (!int.TryParse(Console.ReadLine(), out int horsepower))
    {
        Console.WriteLine("Ошибка: введите целое число.");
        return;
    }

    try
    {
        var car = new Car(0, brandId, name, horsepower);
        db.AddCar(car);
        Console.WriteLine("Автомобиль добавлен.");
    }
    catch (ArgumentException ex)
    {
        Console.WriteLine($"Ошибка: {ex.Message}");
    }
}

static void EditCar(DatabaseManager db)
{
    Console.WriteLine("--- Редактирование автомобиля ---");
    Console.Write("Введите ID автомобиля: ");
    if (!int.TryParse(Console.ReadLine(), out int id))
    {
        Console.WriteLine("Ошибка: введите целое число.");
        return;
    }

    var car = db.GetCarById(id);
    if (car == null)
    {
        Console.WriteLine($"Автомобиль с ID={id} не найден.");
        return;
    }

    Console.WriteLine($"Текущие данные: {car}");
    Console.WriteLine("(Нажмите Enter, чтобы оставить значение без изменений)");

    // Название
    Console.Write($"Название [{car.Name}]: ");
    string input = Console.ReadLine()?.Trim() ?? "";
    if (input.Length > 0) car.Name = input;

    // Марка
    Console.Write($"ID марки [{car.BrandId}]: ");
    input = Console.ReadLine()?.Trim() ?? "";
    if (input.Length > 0 && int.TryParse(input, out int newBrandId))
        car.BrandId = newBrandId;

    // Мощность
    Console.Write($"Мощность [{car.Horsepower}]: ");
    input = Console.ReadLine()?.Trim() ?? "";
    if (input.Length > 0 && int.TryParse(input, out int newHorsepower))
    {
        try
        {
            car.Horsepower = newHorsepower;
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
            return;
        }
    }

    db.UpdateCar(car);
    Console.WriteLine("Данные обновлены.");
}

static void DeleteCar(DatabaseManager db)
{
    Console.WriteLine("--- Удаление автомобиля ---");
    Console.Write("Введите ID автомобиля: ");
    if (!int.TryParse(Console.ReadLine(), out int id))
    {
        Console.WriteLine("Ошибка: введите целое число.");
        return;
    }

    var car = db.GetCarById(id);
    if (car == null)
    {
        Console.WriteLine($"Автомобиль с ID={id} не найден.");
        return;
    }

    Console.Write($"Удалить «{car.Name}»? (да/нет): ");
    string confirm = Console.ReadLine()?.Trim().ToLower() ?? "";
    if (confirm == "да")
    {
        db.DeleteCar(id);
        Console.WriteLine("Автомобиль удалён.");
    }
    else
    {
        Console.WriteLine("Удаление отменено.");
    }
}

// ==================== Подменю отчётов ====================

static void ReportsMenu(DatabaseManager db)
{
    string choice;
    do
    {
        Console.WriteLine("--- Отчёты ---");
        Console.WriteLine(" 1 - Список автомобилей с названиями марок");
        Console.WriteLine(" 2 - Количество автомобилей по маркам");
        Console.WriteLine(" 3 - Средняя мощность по маркам");
        Console.WriteLine(" 0 - Назад");
        Console.Write("Ваш выбор: ");
        choice = Console.ReadLine()?.Trim() ?? "";

        switch (choice)
        {
            case "1": Report1_CarsWithBrands(db); break;
            case "2": Report2_CountByBrand(db); break;
            case "3": Report3_AvgHorsepowerByBrand(db); break;
            case "0": break;
            default: Console.WriteLine("Неверный пункт."); break;
        }
        Console.WriteLine();
    } while (choice != "0");
}

// Отчёт 1: Автомобили с названиями марок (JOIN)
static void Report1_CarsWithBrands(DatabaseManager db)
{
    new ReportBuilder(db)
        .Query(@"
            SELECT c.car_name, b.brand_name, c.horsepower
            FROM car c
            JOIN carbrand b ON c.brand_id = b.brand_id
            ORDER BY c.car_name")
        .Title("Автомобили по маркам")
        .Header("Модель", "Марка", "Мощность (л.с.)")
        .ColumnWidths(20, 18, 15)
        .Numbered()
        .Footer("Всего автомобилей")
        .Print();
}

// Отчёт 2: Количество автомобилей по маркам (GROUP BY + COUNT)
static void Report2_CountByBrand(DatabaseManager db)
{
    new ReportBuilder(db)
        .Query(@"
            SELECT b.brand_name, COUNT(*) AS cnt
            FROM car c
            JOIN carbrand b ON c.brand_id = b.brand_id
            GROUP BY b.brand_name
            ORDER BY b.brand_name")
        .Title("Количество автомобилей по маркам")
        .Header("Марка", "Кол-во")
        .ColumnWidths(20, 10)
        .Print();
}

// Отчёт 3: Средняя мощность по маркам (GROUP BY + AVG)
static void Report3_AvgHorsepowerByBrand(DatabaseManager db)
{
    new ReportBuilder(db)
        .Query(@"
            SELECT b.brand_name, ROUND(AVG(c.horsepower), 1) AS avg_hp
            FROM car c
            JOIN carbrand b ON c.brand_id = b.brand_id
            GROUP BY b.brand_name
            ORDER BY avg_hp DESC")
        .Title("Средняя мощность по маркам")
        .Header("Марка", "Средняя мощность (л.с.)")
        .ColumnWidths(20, 25)
        .Print();
}

// [ГРУППА Г] Фильтр по марке
static void FilterByBrand(DatabaseManager db)
{
    Console.WriteLine("--- Фильтр по марке ---");
    Console.WriteLine("Доступные марки:");
    var brands = db.GetAllBrands();
    foreach (var brand in brands) Console.WriteLine(" " + brand);

    Console.Write("Введите ID марки: ");
    if (!int.TryParse(Console.ReadLine(), out int brandId))
    {
        Console.WriteLine("Ошибка: введите целое число.");
        return;
    }

    var cars = db.GetCarsByBrand(brandId);
    if (cars.Count == 0)
    {
        Console.WriteLine("В этой марке нет автомобилей.");
        return;
    }

    Console.WriteLine($"\nАвтомобили марки #{brandId}:");
    foreach (var car in cars)
        Console.WriteLine(" " + car);
    Console.WriteLine($"Итого: {cars.Count}");
}

// [ГРУППА Б] Экспорт в CSV
static void ExportCsv(DatabaseManager db)
{
    string brandPath = Path.Combine(AppContext.BaseDirectory, "carbrands_export.csv");
    string carPath = Path.Combine(AppContext.BaseDirectory, "cars_export.csv");
    db.ExportToCsv(brandPath, carPath);
    Console.WriteLine($"Марки экспортированы в: {brandPath}");
    Console.WriteLine($"Автомобили экспортированы в: {carPath}");
}