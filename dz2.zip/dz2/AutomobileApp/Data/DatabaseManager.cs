using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

/// <summary>
/// Управление базой данных SQLite.
/// Инкапсулирует все операции с БД: создание таблиц,
/// импорт CSV, CRUD-операции, выполнение запросов для отчётов.
/// </summary>
class DatabaseManager
{
    private string _connectionString;

    /// <summary>
    /// Конструктор. Принимает путь к файлу БД.
    /// </summary>
    public DatabaseManager(string dbPath)
    {
        _connectionString = $"Data Source={dbPath}";
    }

    // ==================== Инициализация ====================

    /// <summary>
    /// Создаёт таблицы (если не существуют) и загружает CSV при первом запуске
    /// </summary>
    public void InitializeDatabase(string brandCsvPath, string carCsvPath)
    {
        CreateTables();

        if (GetAllBrands().Count == 0 && File.Exists(brandCsvPath))
        {
            ImportBrandsFromCsv(brandCsvPath);
            Console.WriteLine($"[OK] Загружены марки из {brandCsvPath}");
        }

        if (GetAllCars().Count == 0 && File.Exists(carCsvPath))
        {
            ImportCarsFromCsv(carCsvPath);
            Console.WriteLine($"[OK] Загружены автомобили из {carCsvPath}");
        }
    }

    /// <summary>Создание таблиц</summary>
    private void CreateTables()
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            CREATE TABLE IF NOT EXISTS carbrand (
                brand_id INTEGER PRIMARY KEY AUTOINCREMENT,
                brand_name TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS car (
                car_id INTEGER PRIMARY KEY AUTOINCREMENT,
                brand_id INTEGER NOT NULL,
                car_name TEXT NOT NULL,
                horsepower INTEGER NOT NULL,
                FOREIGN KEY (brand_id) REFERENCES carbrand(brand_id)
            );
        ";
        cmd.ExecuteNonQuery();
    }

    /// <summary>Импорт марок из CSV</summary>
    private void ImportBrandsFromCsv(string path)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        string[] lines = File.ReadAllLines(path);
        for (int i = 1; i < lines.Length; i++)
        {
            string[] parts = lines[i].Split(';');
            if (parts.Length < 2) continue;
            var cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO carbrand (brand_id, brand_name) VALUES (@id, @name)";
            cmd.Parameters.AddWithValue("@id", int.Parse(parts[0]));
            cmd.Parameters.AddWithValue("@name", parts[1]);
            cmd.ExecuteNonQuery();
        }
    }

    /// <summary>Импорт автомобилей из CSV</summary>
    private void ImportCarsFromCsv(string path)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        string[] lines = File.ReadAllLines(path);
        for (int i = 1; i < lines.Length; i++)
        {
            string[] parts = lines[i].Split(';');
            if (parts.Length < 4) continue;
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO car (car_id, brand_id, car_name, horsepower)
                VALUES (@id, @brandId, @name, @horsepower)";
            cmd.Parameters.AddWithValue("@id", int.Parse(parts[0]));
            cmd.Parameters.AddWithValue("@brandId", int.Parse(parts[1]));
            cmd.Parameters.AddWithValue("@name", parts[2]);
            cmd.Parameters.AddWithValue("@horsepower", int.Parse(parts[3]));
            cmd.ExecuteNonQuery();
        }
    }

    // ==================== Чтение данных ====================

    /// <summary>Получить все марки</summary>
    public List<CarBrand> GetAllBrands()
    {
        var result = new List<CarBrand>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT brand_id, brand_name FROM carbrand ORDER BY brand_id";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new CarBrand(reader.GetInt32(0), reader.GetString(1)));
        }
        return result;
    }

    /// <summary>Получить все автомобили</summary>
    public List<Car> GetAllCars()
    {
        var result = new List<Car>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT car_id, brand_id, car_name, horsepower FROM car ORDER BY car_id";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new Car(reader.GetInt32(0), reader.GetInt32(1), reader.GetString(2), reader.GetInt32(3)));
        }
        return result;
    }

    /// <summary>Получить автомобиль по Id</summary>
    public Car? GetCarById(int id)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT car_id, brand_id, car_name, horsepower FROM car WHERE car_id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        using var reader = cmd.ExecuteReader();
        if (reader.Read())
        {
            return new Car(reader.GetInt32(0), reader.GetInt32(1), reader.GetString(2), reader.GetInt32(3));
        }
        return null;
    }

    // ==================== Изменение данных ====================

    /// <summary>Добавить автомобиль (Id генерируется автоматически)</summary>
    public void AddCar(Car car)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            INSERT INTO car (brand_id, car_name, horsepower)
            VALUES (@brandId, @name, @horsepower)";
        cmd.Parameters.AddWithValue("@brandId", car.BrandId);
        cmd.Parameters.AddWithValue("@name", car.Name);
        cmd.Parameters.AddWithValue("@horsepower", car.Horsepower);
        cmd.ExecuteNonQuery();
    }

    /// <summary>Обновить данные автомобиля</summary>
    public void UpdateCar(Car car)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            UPDATE car
            SET brand_id = @brandId, car_name = @name, horsepower = @horsepower
            WHERE car_id = @id";
        cmd.Parameters.AddWithValue("@id", car.Id);
        cmd.Parameters.AddWithValue("@brandId", car.BrandId);
        cmd.Parameters.AddWithValue("@name", car.Name);
        cmd.Parameters.AddWithValue("@horsepower", car.Horsepower);
        cmd.ExecuteNonQuery();
    }

    /// <summary>Удалить автомобиль по Id</summary>
    public void DeleteCar(int id)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "DELETE FROM car WHERE car_id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }

    // ==================== Выполнение произвольного запроса (для отчётов) ====================

    /// <summary>
    /// Выполняет SQL-запрос и возвращает имена столбцов и строки результата.
    /// Используется классом ReportBuilder.
    /// </summary>
    public (string[] columns, List<string[]> rows) ExecuteQuery(string sql)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        using var reader = cmd.ExecuteReader();

        string[] columns = new string[reader.FieldCount];
        for (int i = 0; i < reader.FieldCount; i++)
            columns[i] = reader.GetName(i);

        var rows = new List<string[]>();
        while (reader.Read())
        {
            string[] row = new string[reader.FieldCount];
            for (int i = 0; i < reader.FieldCount; i++)
                row[i] = reader.GetValue(i)?.ToString() ?? "";
            rows.Add(row);
        }
        return (columns, rows);
    }

    // ==================== Дополнительные методы ====================

    /// <summary>Экспорт обеих таблиц в CSV-файлы [ГРУППА Б]</summary>
    public void ExportToCsv(string brandPath, string carPath)
    {
        var brandLines = new List<string> { "brand_id;brand_name" };
        foreach (var brand in GetAllBrands())
            brandLines.Add($"{brand.Id};{brand.Name}");
        File.WriteAllLines(brandPath, brandLines);

        var carLines = new List<string> { "car_id;brand_id;car_name;horsepower" };
        foreach (var car in GetAllCars())
            carLines.Add($"{car.Id};{car.BrandId};{car.Name};{car.Horsepower}");
        File.WriteAllLines(carPath, carLines);
    }

    /// <summary>Получить автомобили конкретной марки [ГРУППА Г]</summary>
    public List<Car> GetCarsByBrand(int brandId)
    {
        var result = new List<Car>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            SELECT car_id, brand_id, car_name, horsepower
            FROM car WHERE brand_id = @brandId ORDER BY car_name";
        cmd.Parameters.AddWithValue("@brandId", brandId);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new Car(reader.GetInt32(0), reader.GetInt32(1), reader.GetString(2), reader.GetInt32(3)));
        }
        return result;
    }
}