/// <summary>
/// Автомобильная марка (справочная таблица, сторона «один»)
/// </summary>
class CarBrand
{
    /// <summary>Идентификатор марки</summary>
    public int Id { get; set; }

    /// <summary>Название марки</summary>
    public string Name { get; set; }

    /// <summary>Конструктор с параметрами</summary>
    public CarBrand(int id, string name)
    {
        Id = id;
        Name = name;
    }

    /// <summary>Конструктор по умолчанию</summary>
    public CarBrand() : this(0, "") { }

    public override string ToString() => $"[{Id}] {Name}";
}