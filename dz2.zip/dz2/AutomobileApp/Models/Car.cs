/// <summary>
/// Автомобиль (основная таблица, сторона «много»)
/// </summary>
class Car
{
    /// <summary>Идентификатор автомобиля</summary>
    public int Id { get; set; }

    /// <summary>Идентификатор марки (внешний ключ)</summary>
    public int BrandId { get; set; }

    /// <summary>Название модели автомобиля</summary>
    public string Name { get; set; }

    private int _horsepower;

    /// <summary>
    /// Мощность двигателя в л.с. (не может быть отрицательной)
    /// </summary>
    public int Horsepower
    {
        get => _horsepower;
        set
        {
            if (value < 0)
                throw new ArgumentException("Мощность двигателя не может быть отрицательной");
            _horsepower = value;
        }
    }

    /// <summary>Конструктор с параметрами</summary>
    public Car(int id, int brandId, string name, int horsepower)
    {
        Id = id;
        BrandId = brandId;
        Name = name;
        Horsepower = horsepower;
    }

    /// <summary>Конструктор по умолчанию</summary>
    public Car() : this(0, 0, "", 0) { }

    public override string ToString() => $"[{Id}] {Name}, марка #{BrandId}, мощность: {Horsepower} л.с.";
}